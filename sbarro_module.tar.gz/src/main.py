import asyncio
from datetime import datetime
from dotenv import load_dotenv
import os
from typing import Any, ClassVar, Final, Mapping, Optional, Sequence

from typing_extensions import Self
from viam.components.sensor import *
from viam.logging import getLogger
from viam.module.module import Module
from viam.proto.app.robot import ComponentConfig
from viam.proto.common import ResourceName
from viam.resource.base import ResourceBase
from viam.resource.easy_resource import EasyResource
from viam.resource.types import Model, ModelFamily
from viam.robot.client import RobotClient
from viam.services.vision import VisionClient
from viam.utils import SensorReading
from viam.rpc.dial import DialOptions, Credentials
from viam.app.viam_client import ViamClient

logger = getLogger(__name__)

load_dotenv()

class SbarroData(Sensor, EasyResource):
    MODEL: ClassVar[Model] = Model(
        ModelFamily("brad-grigsby", "my-sbarro-sensor"), "sbarro-data"
    )

    def __init__(self, name, *, logger = None):
        super().__init__(name, logger=logger)
        self.machine = None
        self.viam_client = None
        self.vision_service = None
        self.connected = False

    @classmethod
    def new(
        cls, config: ComponentConfig, dependencies: Mapping[ResourceName, ResourceBase]
    ) -> Self:
        """This method creates a new instance of this Sensor component.
        The default implementation sets the name from the `config` parameter and then calls `reconfigure`.

        Args:
            config (ComponentConfig): The configuration for this resource
            dependencies (Mapping[ResourceName, ResourceBase]): The dependencies (both implicit and explicit)

        Returns:
            Self: The resource
        """
        return super().new(config, dependencies)

    @classmethod
    def validate_config(cls, config: ComponentConfig) -> Sequence[str]:
        """This method allows you to validate the configuration object received from the machine,
        as well as to return any implicit dependencies based on that `config`.

        Args:
            config (ComponentConfig): The configuration for this resource

        Returns:
            Sequence[str]: A list of implicit dependencies
        """
        return []

    def reconfigure(
        self, config: ComponentConfig, dependencies: Mapping[ResourceName, ResourceBase]
    ):
        """This method allows you to dynamically update your service when it receives a new `config` object.

        Args:
            config (ComponentConfig): The new configuration
            dependencies (Mapping[ResourceName, ResourceBase]): Any dependencies (both implicit and explicit)
        """
        return super().reconfigure(config, dependencies)
    
    async def connect(self):
        # Connect to machine
        try:
            opts = RobotClient.Options.with_api_key( 
                api_key='65epjxb2usc5bnb23eicafnljeyovwt9',
                api_key_id='e44389fc-55ec-409a-bb0f-7dd274a55faa'
            )
        except Exception as e:
            raise Exception(f"Error creating options: {e}")
        
        try:
            self.machine = await RobotClient.at_address('test-sbarro-main.8l4pdya4yy.viam.cloud', opts)
        except Exception as e:
            raise Exception(f"Error connecting to machine: {e}")
        
        try:
            self.vision_service = VisionClient.from_robot(self.machine, "vision-1")
        except Exception as e:
            raise Exception(f"Error connecting to vision service: {e}")
        
        # Connect to Viam Client
        dial_options = DialOptions(
        credentials=Credentials(
            type="api-key",
            payload=os.getenv("API_KEY"),
        ),
        auth_entity=os.getenv("API_KEY_ID")
        )
        self.viam_client = await ViamClient.create_from_dial_options(dial_options)

        self.connected = True
        return

    async def get_readings(
        self,
        *,
        extra: Optional[Mapping[str, Any]] = None,
        timeout: Optional[float] = None,
        **kwargs
    ) -> Mapping[str, SensorReading]:
        if not self.connected:
            try:
                await self.connect()
            except Exception as e:
                raise Exception(f"Error connecting to machine: {e}")

        # Get fleet specific information
        location = "Test"
        try:
            app_client = self.viam_client.app_client
            location_id = "8l4pdya4yy"
            location = await app_client.get_location(location_id=location_id)
        except Exception as e:
            raise Exception(f"Error getting location information: {e}") 
        

        # detections = await self.vision_service.get_detections_from_camera("camera-1")

        # test = False
        # for detection in detections:
        #     if detection.class_name.lower() == "person" and detection.confidence > 0.8:
        #         test = True
        fake_detections = "pizza_12_20241215_184330"
        initial_timestamp = "_".join(fake_detections.split("_")[2:])
        total_pizzas = int(fake_detections.split("_")[1])
        test = False
        current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        return {
            "location_name": location.name,
            "total_hold_time": 344,
            "trays_over_hold": 267,
            "total_trays_expired": 33,
            "test": test,
            "total_trays": total_pizzas,
            "initial_timestamp": initial_timestamp,
            "current_timestamp": current_timestamp,
        }


if __name__ == "__main__":
    asyncio.run(Module.run_from_registry())

